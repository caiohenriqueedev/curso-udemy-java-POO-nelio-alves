package primeiroexercicio;

public class PrimeiroExercicio {

   
    public static void main(String[] args) {
 
    }
    
}
